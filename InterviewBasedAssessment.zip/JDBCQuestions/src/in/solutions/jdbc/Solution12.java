package in.solutions.jdbc;

import java.sql.*;
import java.util.Scanner;

public class Solution12 {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
    private static final String USERNAME = "your-username";
    private static final String PASSWORD = "your-password";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the CRUD Application");

        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            while (true) {
                System.out.println("Menu:");
                System.out.println("1. Add Record");
                System.out.println("2. View Records");
                System.out.println("3. Update Record");
                System.out.println("4. Delete Record");
                System.out.println("0. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        addRecord(connection, scanner);
                        break;
                    case 2:
                        viewRecords(connection);
                        break;
                    case 3:
                        updateRecord(connection, scanner);
                        break;
                    case 4:
                        deleteRecord(connection, scanner);
                        break;
                    case 0:
                        System.out.println("Exiting the application.");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                        break;
                }

                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addRecord(Connection connection, Scanner scanner) throws SQLException {
        System.out.println("Add Record");
        System.out.print("Enter name: ");
        String name = scanner.next();
        System.out.print("Enter age: ");
        int age = scanner.nextInt();

        String insertQuery = "INSERT INTO mytable (name, age) VALUES (?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
        preparedStatement.setString(1, name);
        preparedStatement.setInt(2, age);
        int rowsAffected = preparedStatement.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Record added successfully.");
        } else {
            System.out.println("Failed to add record.");
        }
    }

    private static void viewRecords(Connection connection) throws SQLException {
        System.out.println("View Records");

        String selectQuery = "SELECT * FROM mytable";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(selectQuery);

        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String name = resultSet.getString("name");
            int age = resultSet.getInt("age");

            System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age);
        }
    }

    private static void updateRecord(Connection connection, Scanner scanner) throws SQLException {
        System.out.println("Update Record");
        System.out.print("Enter the ID of the record to update: ");
        int id = scanner.nextInt();

        System.out.print("Enter new name: ");
        String name = scanner.next();
        System.out.print("Enter new age: ");
        int age = scanner.nextInt();

        String updateQuery = "UPDATE mytable SET name = ?, age = ? WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
        preparedStatement.setString(1, name);
        preparedStatement.setInt(2, age);
        preparedStatement.setInt(3, id);
        int rowsAffected = preparedStatement.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Record updated successfully.");
        } else {
            System.out.println("No Record Found");
        }
    }
    
    private static void deleteRecord(Connection connection, Scanner scanner) throws SQLException {
        System.out.println("delete Record");
        System.out.print("Enter the ID of the record to deleted: ");
        int id = scanner.nextInt();

        

        String updateQuery = "DELETE FROM mytable WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
        preparedStatement.setInt(1, id);
        int rowsAffected = preparedStatement.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Record deleted successfully.");
        } else {
            System.out.println("No Record Found");
        }
    }
}

