package in.solutions.java;

//Example using Interface:

interface Vehicle {
    void start();
    void stop();
}

class Car implements Vehicle {
    public void start() {
        System.out.println("Car started");
    }

    public void stop() {
        System.out.println("Car stopped");
    }
}

class Bike implements Vehicle {
    public void start() {
        System.out.println("Bike started");
    }

    public void stop() {
        System.out.println("Bike stopped");
    }
}

public class Solution5Interface {
    public static void main(String[] args) {
        Vehicle car = new Car();
        car.start(); // Output: Car started
        car.stop(); // Output: Car stopped

        Vehicle bike = new Bike();
        bike.start(); // Output: Bike started
        bike.stop(); // Output: Bike stopped
    }
}

/*
Key Differences between Abstract Classes and Interfaces:

Definition: An abstract class is a class that cannot be instantiated and is typically used as a base for its subclasses. An interface is a reference type that defines a contract for classes to implement certain methods.

Instantiation: Abstract classes cannot be instantiated using the new keyword, while interfaces cannot be instantiated at all. However, concrete subclasses can be created for both abstract classes and interfaces.

Inheritance: A class can extend only one abstract class but can implement multiple interfaces. This allows for more flexibility in terms of reusing code through interfaces.

Method Implementation: An abstract class can have both abstract and non-abstract methods. It can provide default implementations for some methods and leave others abstract, which the subclasses must implement. On the other hand, all methods defined in an interface are implicitly abstract, and the implementing class must provide implementations for all interface methods.

Access Modifiers: In an abstract class, methods can have different access modifiers (public, protected, or default) based on the design requirements. In interfaces, all methods are implicitly public and cannot have any other access modifier.

Fields and Constants: An abstract class can have instance variables, fields, and non-constant static variables. It can also define constants. Interfaces
*/
