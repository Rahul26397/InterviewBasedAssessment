package in.solutions.java;
import java.util.ArrayList;
import java.util.List;

public class Solution6 {
    public static void main(String[] args) {
        // Creating a large data set
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 1000000; i++) {
            numbers.add(i);
        }

        // Example operations using Stream API
        numbers.stream()
                .filter(n -> n % 2 == 0) // Filter even numbers
                .map(n -> n * 2) // Double each number
                .sorted() // Sort the numbers in ascending order
                .limit(10) // Limit the output to 10 numbers
                .forEach(System.out::println); // Print the numbers
    }
}
