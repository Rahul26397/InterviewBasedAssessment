package in.solutions.java;

class Parent {
    public Parent() {
        System.out.println("Parent class constructor invoked");
    }
}

class Child extends Parent {
    public Child() {
        super(); // Invoking parent class constructor
        System.out.println("Child class constructor invoked");
    }
}

public class solution2 {
    public static void main(String[] args) {
        Child child = new Child();
    }
}


/*  key points about constructors:

A constructor is a special member method of a class that is used to initialize objects of that class.
The name of the constructor must be the same as the name of the class.
Constructors do not have a return type, not even void.
If a class does not define any constructors, a default constructor (parameterless constructor) is automatically provided by the compiler.
Constructors can be overloaded, which means a class can have multiple constructors with different parameter lists.
The super() keyword is used to explicitly invoke the parent class constructor from the child class constructor. It should be the first statement in the child class constructor if used.
If the parent class does not have a parameterless constructor, the child class constructor must use super(...) to invoke a specific parent class constructor with the required parameters.
If the super() statement is not explicitly used in the child class constructor, the default (parameterless) constructor of the parent class is implicitly invoked.
Constructors can also invoke other constructors within the same class using the this(...) keyword, allowing constructor chaining. */