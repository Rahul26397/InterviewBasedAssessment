package in.solutions.servlet.main;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/WelcomeServlet")
public class Solution14 extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Read the name parameter from the request
        String name = request.getParameter("name");
        
        // Set the response content type
        response.setContentType("text/html");
        
        // Create the welcome message
        String message = "Welcome, " + name + "!";
        
        // Write the welcome message to the response
        response.getWriter().println("<html>");
        response.getWriter().println("<head><title>Welcome Page</title></head>");
        response.getWriter().println("<body>");
        response.getWriter().println("<h1>" + message + "</h1>");
        response.getWriter().println("</body>");
        response.getWriter().println("</html>");
    }
}
